from app import db
from app.models.base import BaseModel


class Cliente(BaseModel):
    __tablename__ = "clientes"

    representante = db.Column(
        db.String(150),
        nullable=False
    )

    responsavel = db.Column(
        db.String(150),
        nullable=False
    )

    cpf = db.Column(
        db.String(14),
        nullable=False,
        unique=True
    )

    telefone = db.Column(
        db.String(20),
        nullable=False
    )

    endereco = db.Column(
        db.String(250)
    )

    observacoes = db.Column(
        db.Text
    )

    def __repr__(self):
        return f"<Cliente {self.representante}>"