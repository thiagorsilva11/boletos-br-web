from app import db
from app.models.cliente import Cliente


class ClienteService:

    @staticmethod
    def listar():
        return Cliente.query.order_by(Cliente.representante).all()

    @staticmethod
    def buscar(id):
        return Cliente.query.get_or_404(id)

    @staticmethod
    def criar(form):

        cliente = Cliente(
            representante=form.representante.data,
            responsavel=form.responsavel.data,
            cpf=form.cpf.data,
            telefone=form.telefone.data,
            endereco=form.endereco.data,
            observacoes=form.observacoes.data
        )

        db.session.add(cliente)
        db.session.commit()

        return cliente

    @staticmethod
    def atualizar(cliente, form):

        cliente.representante = form.representante.data
        cliente.responsavel = form.responsavel.data
        cliente.cpf = form.cpf.data
        cliente.telefone = form.telefone.data
        cliente.endereco = form.endereco.data
        cliente.observacoes = form.observacoes.data

        db.session.commit()

    @staticmethod
    def excluir(cliente):

        db.session.delete(cliente)
        db.session.commit()